import pandas as pd
import plotly.express as px
from dash import Dash, dcc, html, Input, Output
import dash_bootstrap_components as dbc

# Cargar el archivo CSV
df = pd.read_csv('C:/Users/rodri/Documents/8 SEMESTRE/ANALITICA/Proyecto 1/Proyecto 1/SeoulBikeData_clean.csv')

# Convertir la columna de fechas a formato datetime
df['Date'] = pd.to_datetime(df['Date'], format='%Y-%m-%d')

# Codificar las variables categóricas (Holiday y Seasons) a valores numéricos
df['Holiday'] = df['Holiday'].map({'Holiday': 1, 'No Holiday': 0})
df['Seasons'] = df['Seasons'].map({'Spring': 1, 'Summer': 2, 'Autumn': 3, 'Winter': 4})

# Crear la aplicación Dash
app = Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])

app.layout = dbc.Container([
    html.H1("Tablero de Alquiler de Bicicletas", className="text-center"),
    
    # Selector de fecha
    html.Div([
        html.Label("Seleccionar Fecha:"),
        dcc.DatePickerSingle(
            id='date-picker',
            min_date_allowed=df['Date'].min(),
            max_date_allowed=df['Date'].max(),
            date=df['Date'].min(),
            display_format='YYYY-MM-DD'
        ),
    ]),

    # Gráfico de cantidad de bicicletas alquiladas por hora
    html.Div([
        html.H3("Cantidad de bicicletas alquiladas por hora"),
        dcc.Graph(id='bikes-per-hour'),
    ]),

    # Gráfico de impacto de la temperatura en el uso de bicicletas
    html.Div([
        html.H3("Impacto de la temperatura en el uso de bicicletas"),
        dcc.Graph(id='temp-impact'),
    ]),
])

# Callback para actualizar los gráficos según la fecha seleccionada
@app.callback(
    [Output('bikes-per-hour', 'figure'),
     Output('temp-impact', 'figure')],
    Input('date-picker', 'date')
)
def update_graphs(selected_date):
    filtered_df = df[df['Date'] == selected_date]

    # Gráfico de bicicletas alquiladas por hora
    fig_bikes_per_hour = px.bar(filtered_df, x='Hour', y='Rented Bike Count', title="Bicicletas alquiladas por hora")

    # Gráfico de temperatura vs uso de bicicletas
    fig_temp_impact = px.scatter(filtered_df, x='Temperature(C)', y='Rented Bike Count', title="Impacto de la temperatura en el uso de bicicletas")

    return fig_bikes_per_hour, fig_temp_impact

# Ejecutar la aplicación
if __name__ == '__main__':
    app.run_server(debug=True)








